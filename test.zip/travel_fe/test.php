<iframe src="https://www.google.com/maps/search/?api=1&query=centurylink+field"></iframe>
	<iframe src="https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=48.857832%2C2.295226&heading=-45&pitch=38&fov=80"></iframe>
<a href="https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=13.5984461%2C100.5991077"> Street view</a>
<script defer>
navigator.geolocation.getCurrentPosition(
	(position)=>{
		console.log(position.coords.latitude);
		console.log(position.coords.longitude);
	}


);


</script>