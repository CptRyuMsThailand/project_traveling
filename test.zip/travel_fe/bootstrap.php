<link rel="preload" href="./css/w3.css" annonymous="true" as="style" onload="this.onload=null;this.rel='stylesheet'">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="./css/font.css" />
<link rel="shortcut icon" href="./favicon.jpg" />