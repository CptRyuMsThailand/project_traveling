function w3_open(e_id) {
  document.getElementById(e_id).style.display = "block";
}

function w3_close(e_id) {
  document.getElementById(e_id).style.display = "none";
}
//<img class="w3-hover-opacity" style="width:100%" src="./images/${i.ev_img_list}">