<?php

if(!isset($FROM_INDEX)){
	header("Location:./../index.php");
}



?>