# Traveling Project
## TODO
### HOME 
----

1. Highlight event that nearest occured
2. Preview 4(maybe) event in future
3. Preview 4(maybe) last occured event 

### LIST 
-----

1. Search based on keyword
2. Show result based on keyword


### CALENDAR
-----

1. List event in the calendar based on the how much event they have
